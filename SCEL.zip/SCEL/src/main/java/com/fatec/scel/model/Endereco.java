package com.fatec.scel.model;

public class Endereco {
	String logradouro;
	
	public Endereco() {
		
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}
}

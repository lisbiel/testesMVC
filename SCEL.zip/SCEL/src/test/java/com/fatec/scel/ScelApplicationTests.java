package com.fatec.scel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScelApplicationTests {

	@Test
	void contextLoads() {
	}

}

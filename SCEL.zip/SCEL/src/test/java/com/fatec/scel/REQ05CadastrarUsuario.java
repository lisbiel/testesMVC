package com.fatec.scel;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.fatec.scel.model.LivroRepository;
import com.fatec.scel.model.UsuarioRepository;
import com.fatec.scel.model.*;

@RunWith(SpringRunner.class)
@SpringBootTest
class REQ05CadastrarUsuario {
	@Autowired
	UsuarioRepository repository;

	@Test
	void CT01CadastrarUsuarioComSucesso() {
		repository.deleteAll();
		Usuario usuario = new Usuario("1234", "Humberto Doisberto", "hum@berto.com", "09405-240", "Rua ALegre");
		repository.save(usuario);
		Usuario check = repository.findByRa("1234");
		assertThat(usuario.getNome() == check.getNome());
	}
	
	@Test
	void CT02CadastrarUsuarioComFalha() {
		repository.deleteAll();
		Usuario usuario = new Usuario("1234", "Humberto Doisberto", "hum@berto.com", "09405-240", "Rua ALegre");
		repository.save(usuario);
		Usuario check = new Usuario("1234", "Humberto Doisberto", "hum@berto.com", "09405-240", "Rua ALegre");
		repository.save(check);
		assertThat(usuario.getNome() == check.getNome());
	}

}
